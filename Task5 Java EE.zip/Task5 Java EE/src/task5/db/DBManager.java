package task5.db;

import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.*;
import java.util.ArrayList;
import java.util.Date;

public class DBManager {
    private static Connection connection;

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/aralasu_kz?useUnicode=true&characterEncoding=UTF-8&serverTimezone=UTC", "root", "");

        } catch (Exception e){
            e.printStackTrace();
        }
    }

    public static boolean addUser (User user){
        int rows = 0;

        try {
            PreparedStatement statement = connection.prepareStatement("" +
                    "INSERT INTO users (id, email, password, full_name, birth_date, picture_url)" +
                    " VALUES (NULL, ?, ?, ?, ?, ?)");

            statement.setString(1, user.getEmail());
            statement.setString(2, user.getPassword());
            statement.setString(3, user.getFull_name());
            statement.setString(4, user.getBirth_date());
            statement.setString(5, user.getPicture_url());

            rows = statement.executeUpdate();

            statement.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return rows > 0;
    }
    public static boolean addPost (Post post){
        int rows = 0;

        try {
            PreparedStatement statement = connection.prepareStatement("" +
                    "INSERT INTO posts (id, title, short_content, content, post_date, author_id)" +
                    " VALUES (NULL, ?, ?, ?, NULL, ?)");

            statement.setString(1, post.getTitle());
            statement.setString(2, post.getShort_content());
            statement.setString(3, post.getContent());
            statement.setLong(4, post.getUser().getId());

            rows = statement.executeUpdate();

            statement.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return rows > 0;
    }

    public static User getUser(Long id){
        User user = null;

        try {

            PreparedStatement statement = connection.prepareStatement("" +
                    "SELECT * FROM users WHERE id = ? LIMIT 1");


            statement.setLong(1, id);
            ResultSet resultSet = statement.executeQuery();

            if(resultSet.next()) {
                user = new User(
                        resultSet.getLong("id"),
                        resultSet.getString("email"),
                        resultSet.getString("password"),
                        resultSet.getString("full_name"),
                        resultSet.getString("birth_date"),
                        resultSet.getString("picture_url")
                );
            }

            statement.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return user;
    }
    public static User getUserByEmail(String email){
        User user = null;

        try {

            PreparedStatement statement = connection.prepareStatement("" +
                    "SELECT * FROM users WHERE email = ? LIMIT 1");


            statement.setString(1, email);
            ResultSet resultSet = statement.executeQuery();

            if(resultSet.next()) {
                user = new User(
                        resultSet.getLong("id"),
                        resultSet.getString("email"),
                        resultSet.getString("password"),
                        resultSet.getString("full_name"),
                        resultSet.getString("birth_date"),
                        resultSet.getString("picture_url")
                );
            }

            statement.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return user;
    }
    public static Post getPost(Long id){
        Post post = null;

        try {

            PreparedStatement statement = connection.prepareStatement("" +
                    "SELECT p.id, p.title, p.short_content, p.content, p.post_date, p.author_id," +
                    " u.email AS email, u.password AS password, u.full_name AS full_name, u.birth_date AS birth_date, u.picture_url AS picture_url" +
                    " FROM posts p" +
                    " INNER JOIN users u ON p.author_id = u.id" +
                    " WHERE p.id = ? LIMIT 1");


            statement.setLong(1, id);
            ResultSet resultSet = statement.executeQuery();

            if(resultSet.next()) {
                Date date = resultSet.getTimestamp("post_date");
                String post_date = new SimpleDateFormat("dd.MM.yyyy").format(date);
                post = new Post(
                        resultSet.getLong("id"),
                        resultSet.getString("title"),
                        resultSet.getString("short_content"),
                        resultSet.getString("content"),
                        post_date,
                        new User(
                                resultSet.getLong("author_id"),
                                resultSet.getString("email"),
                                resultSet.getString("password"),
                                resultSet.getString("full_name"),
                                resultSet.getString("birth_date"),
                                resultSet.getString("picture_url")

                        )
                );
            }
            statement.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return post;
    }

    public static ArrayList<User> getAllUsers(){
        ArrayList<User> users = new ArrayList<>();

        try {

            PreparedStatement statement = connection.prepareStatement("" +
                    "SELECT * FROM users");

            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                users.add(new User(
                        resultSet.getLong("id"),
                        resultSet.getString("email"),
                        resultSet.getString("password"),
                        resultSet.getString("full_name"),
                        resultSet.getString("birth_date"),
                        resultSet.getString("picture_url")
                ));
            }

            statement.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return users;
    }
    public static ArrayList<Post> getAllPosts(){
        ArrayList<Post> posts = new ArrayList<>();

        try {

            PreparedStatement statement = connection.prepareStatement("" +
                    "SELECT p.id, p.title, p.short_content, p.content, p.post_date, p.author_id," +
                    " u.email AS email, u.password AS password, u.full_name AS full_name, u.birth_date AS birth_date, u.picture_url AS picture_url" +
                    " FROM posts p" +
                    " INNER JOIN users u ON p.author_id = u.id" +
                    " ORDER BY p.id DESC");

            ResultSet resultSet = statement.executeQuery();

            while(resultSet.next()) {
                Date date = resultSet.getTimestamp("post_date");
                String post_date = new SimpleDateFormat("dd.MM.yyyy").format(date);
                posts.add(new Post(
                        resultSet.getLong("id"),
                        resultSet.getString("title"),
                        resultSet.getString("short_content"),
                        resultSet.getString("content"),
                        post_date,
                        new User(
                                resultSet.getLong("author_id"),
                                resultSet.getString("email"),
                                resultSet.getString("password"),
                                resultSet.getString("full_name"),
                                resultSet.getString("birth_date"),
                                resultSet.getString("picture_url")

                        )
                ));
            }
            statement.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return posts;
    }
    public static ArrayList<Post> getAllPostsOfUser(Long author_id){
        ArrayList<Post> posts = new ArrayList<>();

        try {

            PreparedStatement statement = connection.prepareStatement("" +
                    "SELECT p.id, p.title, p.short_content, p.content, p.post_date, p.author_id," +
                    " u.email AS email, u.password AS password, u.full_name AS full_name, u.birth_date AS birth_date, u.picture_url AS picture_url" +
                    " FROM posts p" +
                    " INNER JOIN users u ON p.author_id = u.id" +
                    " WHERE u.id = ?" +
                    " ORDER BY p.id DESC");


            statement.setLong(1, author_id);
            ResultSet resultSet = statement.executeQuery();

            while(resultSet.next()) {
                Date date = resultSet.getTimestamp("post_date");
                String post_date = new SimpleDateFormat("dd.MM.yyyy").format(date);
                posts.add(new Post(
                        resultSet.getLong("id"),
                        resultSet.getString("title"),
                        resultSet.getString("short_content"),
                        resultSet.getString("content"),
                        post_date,
                        new User(
                                resultSet.getLong("author_id"),
                                resultSet.getString("email"),
                                resultSet.getString("password"),
                                resultSet.getString("full_name"),
                                resultSet.getString("birth_date"),
                                resultSet.getString("picture_url")

                        )
                ));
            }
            statement.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return posts;
    }

    public static boolean saveProfile(User user) {
        int rows = 0;

        try {
            PreparedStatement statement = connection.prepareStatement("" +
                    "UPDATE users SET full_name = ?, birth_date = ?" +
                    " WHERE id = ?");

            statement.setString(1, user.getFull_name());
            statement.setString(2, user.getBirth_date());
            statement.setLong(3, user.getId());

            rows = statement.executeUpdate();

            statement.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return rows > 0;

    }
    public static boolean savePicture(User user) {
        int rows = 0;

        try {
            PreparedStatement statement = connection.prepareStatement("" +
                    "UPDATE users SET picture_url = ?" +
                    " WHERE id = ?");

            statement.setString(1, user.getPicture_url());
            statement.setLong(2, user.getId());

            rows = statement.executeUpdate();

            statement.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return rows > 0;

    }
    public static boolean savePassword(User user) {
        int rows = 0;

        try {
            PreparedStatement statement = connection.prepareStatement("" +
                    "UPDATE users SET password = ?" +
                    " WHERE id = ?");

            statement.setString(1, user.getPassword());
            statement.setLong(2, user.getId());

            rows = statement.executeUpdate();

            statement.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return rows > 0;

    }
    public static boolean savePost(Post post) {
        int rows = 0;

        try {
            PreparedStatement statement = connection.prepareStatement("" +
                    "UPDATE posts SET title = ?, short_content = ?, content = ?" +
                    " WHERE id = ?");

            statement.setString(1, post.getTitle());
            statement.setString(2, post.getShort_content());
            statement.setString(3, post.getContent());
            statement.setLong(4, post.getId());


            rows = statement.executeUpdate();

            statement.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return rows > 0;

    }

    public static int findAge(User user) throws ParseException {
        String birthdate = user.getBirth_date();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        Date date = formatter.parse(birthdate);
        Instant instant = date.toInstant();
        ZonedDateTime zone = instant.atZone(ZoneId.systemDefault());
        LocalDate givenDate = zone.toLocalDate();
        Period period = Period.between(givenDate, LocalDate.now());
        return period.getYears();
    }

    public static boolean addFriend(Friend friend) {
        int rows = 0;

        try {
            PreparedStatement statement = connection.prepareStatement("" +
                    "INSERT INTO friends (id, user_id, friend_id, added_time)" +
                    " VALUES (NULL, ?, ?, NULL)");

            statement.setLong(1, friend.getUser().getId());
            statement.setLong(2, friend.getFriend().getId());

            rows = statement.executeUpdate();
            statement.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return rows > 0;
    }
    public static boolean sendRequest(Friend req_friend) {
        int rows = 0;

        try {
            PreparedStatement statement = connection.prepareStatement("" +
                    "INSERT INTO friends_requests (id, user_id, request_sender_id, sent_time)" +
                    " VALUES (NULL, ?, ?, NULL)");

            statement.setLong(1, req_friend.getUser().getId());
            statement.setLong(2, req_friend.getFriend().getId());

            rows = statement.executeUpdate();
            statement.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return rows > 0;
    }

    public static ArrayList<Friend> getAllFriends(Long id){
        ArrayList<Friend> friends = new ArrayList<>();

        try {
            PreparedStatement statement = connection.prepareStatement("" +
                    "SELECT * FROM friends" +
                    " WHERE user_id = ?");

            statement.setLong(1, id);

            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()){
                Date date = resultSet.getTimestamp("added_time");
                String added_time = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(date);
                friends.add(
                        new Friend(
                                resultSet.getLong("id"),
                                getUser(resultSet.getLong("user_id")),
                                getUser(resultSet.getLong("friend_id")),
                                added_time
                        )
                );
            }

            statement.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return friends;
    }
    public static ArrayList<Friend> getAllRequests(Long id){
        ArrayList<Friend> requests = new ArrayList<>();

        try {
            PreparedStatement statement = connection.prepareStatement("" +
                    "SELECT * FROM friends_requests" +
                    " WHERE user_id = ?");

            statement.setLong(1, id);

            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()){
                Date date = resultSet.getTimestamp("sent_time");
                String sent_time = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(date);
                requests.add(
                        new Friend(
                                resultSet.getLong("id"),
                                getUser(resultSet.getLong("user_id")),
                                getUser(resultSet.getLong("request_sender_id")),
                                sent_time
                        )
                );
            }

            statement.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return requests;
    }

    public static boolean deleteFriend(Long user_id, Long friend_id) {
        int rows = 0;

        try {

            PreparedStatement statement = connection.prepareStatement(""+
                    "DELETE FROM friends WHERE user_id = ? AND friend_id = ?");

            statement.setLong(1, user_id);
            statement.setLong(2, friend_id);

            rows = statement.executeUpdate();

            statement.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return rows > 0;
    }
    public static boolean deleteRequest(Long user_id, Long request_sender_id) {
        int rows = 0;

        try {

            PreparedStatement statement = connection.prepareStatement(""+
                    "DELETE FROM friends_requests WHERE user_id = ? AND request_sender_id = ?");

            statement.setLong(1, user_id);
            statement.setLong(2, request_sender_id);

            rows = statement.executeUpdate();

            statement.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return rows > 0;
    }

    public static Chat getChat(Long user_id, Long opponent_user_id){
        Chat chat = null;

        try {

            PreparedStatement statement = connection.prepareStatement("" +
                    "SELECT * FROM chats WHERE user_id = ? and opponent_user_id = ?");


            statement.setLong(1, user_id);
            statement.setLong(2, opponent_user_id);
            ResultSet resultSet = statement.executeQuery();

            if(resultSet.next()) {
                Date date1 = resultSet.getTimestamp("created_date");
                String created_date = new SimpleDateFormat("yyyy-MM-dd").format(date1);
                Date date2 = resultSet.getTimestamp("latest_message_time");
                String latest_message_time = new SimpleDateFormat("HH:mm dd.MM.yyyy").format(date2);
                chat = new Chat(
                        resultSet.getLong("id"),
                        getUser(resultSet.getLong("user_id")),
                        getUser(resultSet.getLong("opponent_user_id")),
                        created_date,
                        resultSet.getString("latest_message_text"),
                        latest_message_time
                );
            }
            statement.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return chat;
    }
    public static Chat getChat(Long id){
        Chat chat = null;

        try {

            PreparedStatement statement = connection.prepareStatement("" +
                    "SELECT * FROM chats WHERE id = ?");


            statement.setLong(1, id);
            ResultSet resultSet = statement.executeQuery();

            if(resultSet.next()) {
                Date date1 = resultSet.getTimestamp("created_date");
                String created_date = new SimpleDateFormat("dd.MM.yyyy").format(date1);
                Date date2 = resultSet.getTimestamp("latest_message_time");
                String latest_message_time = new SimpleDateFormat("HH:mm dd.MM.yyyy").format(date2);
                chat = new Chat(
                        resultSet.getLong("id"),
                        getUser(resultSet.getLong("user_id")),
                        getUser(resultSet.getLong("opponent_user_id")),
                        created_date,
                        resultSet.getString("latest_message_text"),
                        latest_message_time
                );
            }
            statement.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return chat;
    }
    public static Message getMessage(Long chat_id, Long user_id, Long sender_id){
        Message message = null;

        try {

            PreparedStatement statement = connection.prepareStatement("" +
                    "SELECT * FROM messages WHERE chat_id = ? AND user_id = ? and sender_id = ?");


            statement.setLong(1, chat_id);
            statement.setLong(2, user_id);
            statement.setLong(3, sender_id);
            ResultSet resultSet = statement.executeQuery();

            if(resultSet.next()) {
                Date date = resultSet.getTimestamp("sent_date");
                String sent_date = new SimpleDateFormat("HH:mm dd.MM.yyyy").format(date);
                message = new Message(
                        resultSet.getLong("id"),
                        getChat(resultSet.getLong("chat_id")),
                        getUser(resultSet.getLong("user_id")),
                        getUser(resultSet.getLong("sender_id")),
                        resultSet.getString("message_text"),
                        resultSet.getBoolean("read_by_receiver"),
                        sent_date
                );
            }
            statement.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return message;
    }

    public static ArrayList<Chat> getAllChats(){
        ArrayList<Chat> chats = new ArrayList<>();

        try {

            PreparedStatement statement = connection.prepareStatement("" +
                    "SELECT * FROM chats");

            ResultSet resultSet = statement.executeQuery();

            while(resultSet.next()) {
                Date date1 = resultSet.getTimestamp("created_date");
                String created_date = new SimpleDateFormat("yyyy-MM-dd").format(date1);
                Date date2 = resultSet.getTimestamp("latest_message_time");
                String latest_message_time = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(date2);
                chats.add(new Chat(
                        resultSet.getLong("id"),
                        getUser(resultSet.getLong("user_id")),
                        getUser(resultSet.getLong("opponent_user_id")),
                        created_date,
                        resultSet.getString("latest_message_text"),
                        latest_message_time
                ));
            }
            statement.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return chats;
    }
    public static ArrayList<Message> getAllMessages(Long chat_id){
        ArrayList<Message> messages = new ArrayList<>();

        try {

            PreparedStatement statement = connection.prepareStatement("" +
                    "SELECT * FROM messages WHERE chat_id = ? ORDER BY sent_date ASC");

            statement.setLong(1, chat_id);
            ResultSet resultSet = statement.executeQuery();

            while(resultSet.next()) {
                Date date = resultSet.getTimestamp("sent_date");
                String sent_date = new SimpleDateFormat("HH:mm dd.MM.yyyy").format(date);
                messages.add(new Message(
                        resultSet.getLong("id"),
                        getChat(resultSet.getLong("chat_id")),
                        getUser(resultSet.getLong("user_id")),
                        getUser(resultSet.getLong("sender_id")),
                        resultSet.getString("message_text"),
                        resultSet.getBoolean("read_by_receiver"),
                        sent_date
                ));
            }
            statement.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return messages;
    }

    public static boolean addChat (Chat chat){
        int rows = 0;

        try {
            PreparedStatement statement = connection.prepareStatement("" +
                    "INSERT INTO chats (id, user_id, opponent_user_id, created_date, latest_message_text, latest_message_time)" +
                    " VALUES (NULL, ?, ?, NULL, ?, NULL)");

            statement.setLong(1, chat.getUser().getId());
            statement.setLong(2, chat.getOpponent_user().getId());
            statement.setString(3, chat.getLatest_message_text());

            rows = statement.executeUpdate();

            statement.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return rows > 0;
    }
    public static boolean addMessage (Message message){
        int rows = 0;

        try {
            PreparedStatement statement = connection.prepareStatement("" +
                    "INSERT INTO messages (id, chat_id, user_id, sender_id, message_text, read_by_receiver, sent_date)" +
                    " VALUES (NULL, ?, ?, ?, ?, false, NULL)");

            statement.setLong(1, message.getChat().getId());
            statement.setLong(2, message.getUser().getId());
            statement.setLong(3, message.getSender().getId());
            statement.setString(4, message.getMessage_text());

            rows = statement.executeUpdate();

            statement.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return rows > 0;
    }

    public static boolean saveChat(Chat chat) {
        int rows = 0;

        try {
            PreparedStatement statement = connection.prepareStatement("" +
                    "UPDATE chats SET latest_message_text = ?, latest_message_time = now()" +
                    " WHERE id = ?");
            statement.setString(1, chat.getLatest_message_text());
            statement.setLong(2, chat.getId());


            rows = statement.executeUpdate();

            statement.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return rows > 0;
    }
    public static boolean saveMessage(Message message) {
        int rows = 0;

        try {
            PreparedStatement statement = connection.prepareStatement("" +
                    "UPDATE messages SET read_by_receiver = ?" +
                    " WHERE id = ?");
            statement.setBoolean(1, message.isRead_by_receiver());
            statement.setLong(2, message.getId());


            rows = statement.executeUpdate();

            statement.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return rows > 0;
    }

    public static Long second_id(Chat chat, Long first_id) {
        if(first_id.equals(chat.getUser().getId())){
            return chat.getOpponent_user().getId();
        }
        return chat.getUser().getId();
    }

}
