package task5.db;

public class Friend {
    private Long id;
    private User user;
    private User friend;
    private String time;

    public Friend() {
    }

    public Friend(Long id, User user, User friend, String time) {
        this.id = id;
        this.user = user;
        this.friend = friend;
        this.time = time;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public User getFriend() {
        return friend;
    }

    public void setFriend(User friend) {
        this.friend = friend;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}
