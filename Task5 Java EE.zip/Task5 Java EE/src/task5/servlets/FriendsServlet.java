package task5.servlets;

import task5.db.DBManager;
import task5.db.Friend;
import task5.db.Post;
import task5.db.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

@WebServlet(value = "/friends")
public class FriendsServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        User currentUser = (User) request.getSession().getAttribute("CURRENT_USER");
        if(currentUser != null) {
            ArrayList<Friend> friends = DBManager.getAllFriends(currentUser.getId());
            ArrayList<Friend> requests = DBManager.getAllRequests(currentUser.getId());

            ArrayList<Friend> un_confirmed = new ArrayList<>();

            boolean consists = false;

            for(Friend reqFriend : requests) {
                consists = false;
                for(Friend friend : friends){
                    if(reqFriend.getFriend().getId().equals(friend.getFriend().getId())) {
                        consists = true;
                        break;
                    }
                }
                if(!consists) {
                    un_confirmed.add(reqFriend);
                }
            }

            request.setAttribute("friends", friends);
            request.setAttribute("requests", un_confirmed);
            request.setAttribute("user", currentUser);
            request.setAttribute("currentUser", currentUser);
            request.getRequestDispatcher("my_friends.jsp").forward(request, response);
        }
        else {
            response.sendRedirect("/login");
        }
    }
}
