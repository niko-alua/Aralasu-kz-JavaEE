package task5.servlets;

import task5.db.DBManager;
import task5.db.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(value = "/update_password")
public class UpdatePasswordServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        User currentUser = (User) request.getSession().getAttribute("CURRENT_USER");

        String redirect = "/login";

        if(currentUser != null) {
            String old_password = request.getParameter("edit_old_password");
            String new_password = request.getParameter("edit_new_password");
            String re_password = request.getParameter("edit_re_password");
            redirect = "/profile?passError1";
            if (currentUser.getPassword().equals(old_password)) {
                redirect = "/profile?passError2";

                if (re_password.equals(new_password)) {
                    currentUser.setPassword(new_password);

                    if(DBManager.savePassword(currentUser)) {
                        redirect = "/logout";
                    }
                }
            }
        }

        response.sendRedirect(redirect);

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
