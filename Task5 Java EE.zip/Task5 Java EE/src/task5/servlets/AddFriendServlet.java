package task5.servlets;

import task5.db.DBManager;
import task5.db.Friend;
import task5.db.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(value = "/add_friend")
public class AddFriendServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        User currentUser = (User) request.getSession().getAttribute("CURRENT_USER");
        if(currentUser != null) {
            Long reqSenderId = Long.parseLong(request.getParameter("id"));

            User reqSender = DBManager.getUser(reqSenderId);

            Friend friend1 = new Friend(null, currentUser, reqSender, null);
            Friend friend2 = new Friend(null, reqSender, currentUser, null);
            Friend follower = new Friend(null, reqSender, currentUser, null);

            if(DBManager.addFriend(friend1)){
                DBManager.addFriend(friend2);
                DBManager.sendRequest(follower);
                response.sendRedirect("/friends");
            }
        }
        else {
            response.sendRedirect("/login");
        }
    }
}
