package task5.servlets;

import task5.db.Chat;
import task5.db.DBManager;
import task5.db.Message;
import task5.db.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

@WebServlet(value = "/send_message")
public class SendMessageServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        User currentUser = (User) request.getSession().getAttribute("CURRENT_USER");
        if(currentUser != null) {
            Long user_id = Long.parseLong(request.getParameter("user_id"));
            Long sender_id = Long.parseLong(request.getParameter("sender_id"));
            User receiver = DBManager.getUser(user_id);
            User sender = DBManager.getUser(sender_id);
            String message_text = request.getParameter("message_text");

            Chat new_chat = new Chat(null, receiver, sender, null, message_text, null);

            ArrayList<Chat> chats = DBManager.getAllChats();

            if(chats != null) {
                for (Chat chat : chats) {
                    if ((receiver.getId().equals(chat.getUser().getId()) || receiver.getId().equals(chat.getOpponent_user().getId())) && (sender.getId().equals(chat.getUser().getId()) || sender.getId().equals(chat.getOpponent_user().getId()))) {
                        new_chat = chat;
                        new_chat.setLatest_message_text(message_text);
                        new_chat.setLatest_message_time(null);
                        if(DBManager.saveChat(new_chat)){
                            Message message = new Message(null, new_chat, receiver, sender, message_text, false, null);

                            if (DBManager.addMessage(message)) {
                                response.sendRedirect("/chat?id=" + new_chat.getId());
                            }
                        }
                        break;
                    }
                }
            }
            if(new_chat.getId() == null) {
                if (DBManager.addChat(new_chat)) {
                    new_chat = DBManager.getChat(user_id, sender_id);
                    if(new_chat == null){
                        new_chat = DBManager.getChat(sender_id, user_id);
                    }
                    Message message = new Message(null, new_chat, receiver, sender, message_text, false, null);

                    if (DBManager.addMessage(message)) {
                        response.sendRedirect("/chat?id=" + new_chat.getId());
                    }
                }
            }
        }
        else {
            response.sendRedirect("/login");
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
