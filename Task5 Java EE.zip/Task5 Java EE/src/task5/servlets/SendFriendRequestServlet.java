package task5.servlets;

import task5.db.DBManager;
import task5.db.Friend;
import task5.db.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(value = "/send_request")
public class SendFriendRequestServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        User currentUser = (User) request.getSession().getAttribute("CURRENT_USER");
        if(currentUser != null) {
            Long reqToId = Long.parseLong(request.getParameter("id"));
            System.out.println(reqToId);
            User user = DBManager.getUser(reqToId);
            Friend reqFriend = new Friend(null, user, currentUser, null);

            if(DBManager.sendRequest(reqFriend)) {
                response.sendRedirect("/profile?id=" + reqToId);
            }
        }
        else {
            response.sendRedirect("/login");
        }
    }
}
