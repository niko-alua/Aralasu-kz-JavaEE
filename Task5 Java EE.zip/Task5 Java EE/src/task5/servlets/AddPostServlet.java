package task5.servlets;

import task5.db.DBManager;
import task5.db.Post;
import task5.db.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(value = "/add_post")
public class AddPostServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        User currentUser = (User) request.getSession().getAttribute("CURRENT_USER");
        if(currentUser != null) {
            String title = request.getParameter("post_title");
            String short_content = request.getParameter("post_short_content");
            String content = request.getParameter("post_content");

            Post post = new Post(null, title, short_content, content, null, currentUser);

            if (DBManager.addPost(post)) {
                response.sendRedirect("/user_posts");
            }
        }
        else {
            response.sendRedirect("/login");
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
