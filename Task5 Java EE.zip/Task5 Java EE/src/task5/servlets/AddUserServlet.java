package task5.servlets;

import task5.db.DBManager;
import task5.db.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(value = "/adduser")
public class AddUserServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String email = request.getParameter("reg_email");
        String password = request.getParameter("reg_password");
        String re_password = request.getParameter("re_password");
        String full_name = request.getParameter("reg_fullName");
        String birth_date = request.getParameter("reg_birthdate");

        String redirect = "/register?passwordError";

        if(password.equals(re_password)) {
            redirect = "/register?emailError";

            User user = DBManager.getUserByEmail(email);

            if(user == null) {
                User new_user = new User(null, email, password, full_name, birth_date);

                if(DBManager.addUser(new_user)){
                    redirect = "/login";
                }
            }
        }

        response.sendRedirect(redirect);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
