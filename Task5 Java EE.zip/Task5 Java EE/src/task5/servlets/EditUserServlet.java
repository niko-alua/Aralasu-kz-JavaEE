package task5.servlets;

import task5.db.DBManager;
import task5.db.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(value = "/edit_user")
public class EditUserServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        User currentUser = (User) request.getSession().getAttribute("CURRENT_USER");
        String redirect = "/login";
        if(currentUser != null) {
            String full_name = request.getParameter("edit_fullName");
            String birthdate = request.getParameter("edit_birthdate");
            currentUser.setFull_name(full_name);
            currentUser.setBirth_date(birthdate);

            if(DBManager.saveProfile(currentUser)) {
                redirect = "/profile?profile_success";
            }
        }
        response.sendRedirect(redirect);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
