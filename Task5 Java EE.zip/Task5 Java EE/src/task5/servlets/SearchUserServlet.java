package task5.servlets;

import task5.db.DBManager;
import task5.db.Friend;
import task5.db.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

@WebServlet(value = "/search_user")
public class SearchUserServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        User currentUser = (User) request.getSession().getAttribute("CURRENT_USER");
        if(currentUser != null) {
            String search_value = request.getParameter("search_value");

            ArrayList<User> users = DBManager.getAllUsers();

            ArrayList<User> found_users = new ArrayList<>();

            String result = "false";

            for(User user : users) {
                if(user.getFull_name().contains(search_value)){
                    if(!user.getId().equals(currentUser.getId())) {
                        System.out.println(user.getFull_name());
                        found_users.add(user);
                        result = "true";
                    }
                }
            }

            System.out.println(result);


            request.setAttribute("result", result);
            request.setAttribute("found_users", found_users);
            request.getRequestDispatcher("/friends").forward(request, response);
        }
        else {
            response.sendRedirect("/login");
        }
    }
}
