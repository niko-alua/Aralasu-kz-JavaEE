package task5.servlets;

import task5.db.DBManager;
import task5.db.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@WebServlet(value = "/edit_picture")
public class EditUserPictureServlet extends HttpServlet {

    public static boolean isValidURL(String url)
    {
        // Regex to check valid URL
        String regex = "((http|https)://)(www.)?"
                + "[a-zA-Z0-9@:%._\\+~#?&//=]"
                + "{2,256}\\.[a-z]"
                + "{2,6}\\b([-a-zA-Z0-9@:%"
                + "._\\+~#?&//=]*)";


        Pattern p = Pattern.compile(regex);

        if(url == null) {
            return false;
        }

        if(url.isEmpty()) {
            return false;
        }

        Matcher m = p.matcher(url);

        return m.matches();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        User currentUser = (User) request.getSession().getAttribute("CURRENT_USER");

        String redirect = "/login";

        if(currentUser != null) {
            String picture_url = request.getParameter("picture_url");
            if(isValidURL(picture_url)) {
                currentUser.setPicture_url(picture_url);

                if (DBManager.savePicture(currentUser)) {
                    redirect = "/profile?picture_success";
                }
            }
            else {
                redirect = "/profile?picture_error";
            }
        }
        response.sendRedirect(redirect);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
